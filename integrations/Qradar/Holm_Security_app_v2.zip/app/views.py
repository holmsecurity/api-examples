"""
This application will uppdate/add sets of various severities and then update/add ips in the sets.

"""
__author__ = 'Holm Security'

import time
import json
import requests

from app import app, qpylib, render_template, request

# JSON headers for all requests
JSON_HEADERS = {'content-type': 'application/json'}

# Response when a request with no response body is successful
SUCCESS_RESPONSE = {'success': 'true'} 
# Response when a request with no response body fails
FAILURE_RESPONSE = {'success': 'false'}
# Response when a polling request times out
TIMEOUT_RESPONSE = {'error': 'Query timed out'}
 

@app.route('/')
@app.route('/index')
def index():
    """
    Index page, return HTML page with JavaScript embedded calling the
    different endpoints when submitted
    """
    return render_template('index.html')
    
    
@app.route('/integrate')
def hanys_func():
    token = request.args.get('token')
    #check if the sets exists and if not, create them!
    url_holm = request.args.get('url')
    response_sets = qpylib.REST('GET', '/api/reference_data/sets',  headers=JSON_HEADERS).json()

    names_of_exisiting_sets = list()

    names_of_sets = ["Holm_critical_ip_assets", "Holm_high_ip_assets", "Holm_medium_ip_assets", "Holm_low_ip_assets", "Holm_info_ip_assets"]
    for item in response_sets:
        names_of_exisiting_sets.append(item.get("name"))
    for name in names_of_sets:
        if name not in names_of_exisiting_sets:
            send_post_request = qpylib.REST('POST', '/api/reference_data/sets?name=%s&element_type=IP'% name,  headers=JSON_HEADERS).json()
    
            
    # Check if the ips are there or not. If not, then add them
    
    severity_list =  ["info", "low", "high", "medium", "critical"]
    for severity in severity_list: 
        try:

            response = requests.request(
                'GET',
                 url = url_holm + "/public/v2/net-assets?severity=%s&limit=600" % severity,
                headers={"Authorization": "Token %s" % token, "Content-Type": "application/json"},
                verify=False)
                
        except Exception as e:
            return json.dumps({"Message": "Failed to establish integration due to %s" % str(e)})
                
        json_response = response.json()
        
        if json_response.get("description"):
            return json.dumps({"Message":"%s" %json_response["description"]})
        
        for result in json_response.get("results"):
            ip = result.get("ip")
            post_ip = qpylib.REST('POST', '/api/reference_data/sets/Holm_%s_ip_assets?value=%s'% (severity, ip),  headers=JSON_HEADERS).json()
            
    return json.dumps({"Message": "Successfully updated sets with new ips"})



    
